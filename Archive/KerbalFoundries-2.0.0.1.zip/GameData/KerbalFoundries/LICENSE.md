Kerbal Foundries Models and Assets:
Creative Commons CC-BY-NC-SA
https://creativecommons.org/licenses/by-nc-sa/4.0/


Adjustable Landing Gear Models and Assets - modified : 
Originally by Bahamuto-D
License: CC-BY-SA 3.0
https://creativecommons.org/licenses/by-sa/3.0/
Modified and redistributed under terms of license.


KSPWheel - distributed under license, see the KSPWheel license information.

ModuleManager - distributed under license, see the ModuleManager license information.