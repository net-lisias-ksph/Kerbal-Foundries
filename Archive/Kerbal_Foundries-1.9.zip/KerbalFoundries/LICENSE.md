Creative Commons CC BY-SA 2.0

https://creativecommons.org/licenses/by-sa/2.0/
